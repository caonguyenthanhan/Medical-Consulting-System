import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const text = url.searchParams.get('text')
    const lang = url.searchParams.get('lang') || 'vi'

    if (!text || text.trim().length === 0) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 })
    }

    const backendUrl = process.env.BACKEND_URL || 'http://127.0.0.1:8000'
    const target = `${backendUrl}/v1/text-to-speech-stream?text=${encodeURIComponent(text)}&lang=${encodeURIComponent(lang)}`

    const resp = await fetch(target)
    if (!resp.ok || !resp.body) {
      return NextResponse.json({ error: 'Failed to stream audio' }, { status: resp.status || 500 })
    }

    const headers = new Headers(resp.headers)
    headers.set('Content-Type', 'audio/mpeg')
    headers.delete('Content-Length')

    return new Response(resp.body, {
      status: 200,
      headers,
    })
  } catch (error) {
    console.error('Text-to-speech stream API error:', error)
    return NextResponse.json({ error: 'Unexpected error' }, { status: 500 })
  }
}