"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export default function AccountPage() {
  const router = useRouter()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const resp = await fetch("http://127.0.0.1:8000/v1/user")
        if (!resp.ok) return
        const data = await resp.json()
        setUsername(data?.username || "")
      } catch {}
    }
    fetchProfile()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username.trim()) return
    setLoading(true)
    setError(null)
    setSuccess(null)
    try {
      const resp = await fetch("http://127.0.0.1:8000/v1/user", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      })
      if (!resp.ok) {
        const t = await resp.text()
        setError(t || "Cập nhật thất bại")
        setLoading(false)
        return
      }
      setSuccess("Cập nhật thành công. Vui lòng đăng nhập lại.")
      if (typeof window !== 'undefined') {
        try {
          localStorage.removeItem('authToken')
          localStorage.removeItem('userId')
        } catch {}
      }
      setTimeout(() => {
        router.replace('/login')
      }, 800)
    } catch (err: any) {
      setError(err?.message || "Có lỗi xảy ra khi cập nhật")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-50 to-white">
      <div className="w-full max-w-sm bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
        <h1 className="text-xl font-semibold text-gray-900 mb-4">Thông tin tài khoản</h1>
        {error && (
          <div className="mb-3 text-sm text-red-600">{error}</div>
        )}
        {success && (
          <div className="mb-3 text-sm text-green-600">{success}</div>
        )}
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-sm text-gray-700 mb-1">Tên đăng nhập</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl"
              autoComplete="username"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-700 mb-1">Mật khẩu mới</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl"
              autoComplete="new-password"
              placeholder="Để trống nếu không đổi"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Đang lưu...' : 'Lưu thay đổi'}
          </button>
        </form>
        <p className="text-xs text-gray-500 mt-3">Sau khi cập nhật, phiên đăng nhập hiện tại sẽ kết thúc.</p>
      </div>
    </div>
  )
}