"use client"

import { ChatInterface } from "@/components/chat-interface"

export default function ConversationPage({ params }: { params: { id: string } }) {
  return <ChatInterface initialConversationId={params.id} />
}